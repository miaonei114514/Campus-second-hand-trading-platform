package com.schoolshop.dbservice

import com.schoolshop.plugins.database
import org.jetbrains.exposed.dao.id.LongIdTable

object Addresses: LongIdTable() {
  val owner = reference("owner", Users)
  val name = varchar("name", 128)
  val address = varchar("address", 255)
  val phone = varchar("phone", 30)
}

object AddressService: DatabaseService<Long>(database, Addresses)
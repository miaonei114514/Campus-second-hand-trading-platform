package com.schoolshop.plugins

import com.schoolshop.dbservice.*
import com.schoolshop.utils.ErrorRes
import com.schoolshop.utils.SuccessRes
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.server.sessions.*
import org.jetbrains.exposed.sql.SortOrder

fun Application.configureTrades() {
  routing {
    get("/goods-list") {
      val offset = (call.parameters["offset"]?:"0").toLong()
      val amount = call.parameters["amount"]!!.toInt()

      val res = GoodService.filter(amount) { GoodsTable.id greater offset }
      val lastId = if(res.any()) res.last().id else offset

      call.respond(SuccessRes(0, mapOf(
        "list" to res.map { it.toMap() },
        "end" to lastId,
        "noMore" to (lastId < offset + amount)
      )))
    }

    get("/goods-info/{id}") {
      val id = call.parameters["id"]?.toLongOrNull()

      val res = if (id == null) null else GoodService.read(id)

      if (res == null) {
        call.respond(ErrorRes(0, "unknown goods id"))
        return@get
      }

      call.respond(SuccessRes(0, res.toMap()))
    }

    get("/grt-cart/{uid}") {

    }

    post("/make-trade") {

    }

    route("/goods-topics/{id}"){
      get {
        val id = call.parameters["id"]?.toLong()

        val res = if (id == null) null else GoodService.read(id)

        if (res == null) {
          call.respond(ErrorRes(0, "unknown goods id"))
          return@get
        }

        val topics = TopicService.filter{ Topics.target eq id }
        call.respond(SuccessRes(0, topics.map { it.toMap() }))
      }

      post {
        val id = call.parameters["id"]?.toLong()

        val param = call.receiveParameters()
        val target = param["target"]?.toLong()!!
        val content = param["content"]!!

        val publisher = call.sessions.get("USER_CONTEXT") as? UserContext
        if (publisher == null) {
          call.respond(ErrorRes(0, "no user logged in"))
          return@post
        }

        val res = if (id == null) null else GoodService.read(id)
        if (res == null) {
          call.respond(ErrorRes(0, "unknown goods id"))
          return@post
        }

        TopicService.create(
          Topics.target to target,
          Topics.publisher to publisher.id,
          Topics.content to content,
        )

        call.respond(SuccessRes(0, null))
      }
    }

    post("/delete-topic"){
      val param = call.receiveParameters()
      val id = param["topicId"]?.toLong()

      val topic = TopicService.read(id!!)
      if (topic == null) {
        call.respond(ErrorRes(0, "no such topic with id $id"))
        return@post
      }

      val publisher = call.sessions.get("USER_CONTEXT") as? UserContext
      if (publisher == null) {
        call.respond(ErrorRes(0, "no user logged in"))
        return@post
      }

      if (topic[Topics.publisher]?.value != publisher.id){
        call.respond(ErrorRes(0, "no permission to delete this topic"))
        return@post
      }

      TopicService.delete(id)
      call.respond(SuccessRes(0, null))
    }

    get("/usercontext/publich-goods/{uid}") {
      val batch = call.parameters["patch"]?.toInt()
      val uid = call.parameters["uid"]?.toIntOrNull()?:call.parameters["uid"]
      val user = UserService.find { if(uid is String) Users.uid eq uid else Users.id eq uid as Int }

      if (user == null) {
        call.respond(ErrorRes(0, "no such user"))
        return@get
      }

      val goods = GoodService.filter(
        batch?:10000,
        GoodsTable.createTime to SortOrder.ASC
      ) { GoodsTable.owner eq user.id}

      call.respond(SuccessRes(0, goods.map { it.toMap() }))
    }
  }

}

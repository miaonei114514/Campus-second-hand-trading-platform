import {buildTopBar} from "../scripts/components";
import $ from "jquery";
import {CartInfo, Result, UserInfo} from "../scripts/types";

buildTopBar("cart")

let loginUsr: UserInfo

$.get("usercontext", (res: Result<UserInfo>) => {
  if (res.status == "error") window.location.href = "/login";
  else {
    loginUsr = res.obj;

    $.get(`/grt-cart/${loginUsr.uid}`, (res: Result<CartInfo[]>) => {

    })
  }
})

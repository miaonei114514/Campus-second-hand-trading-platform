"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const components_1 = require("../scripts/components");
const jquery_1 = __importDefault(require("jquery"));
(0, components_1.buildTopBar)("cart");
let loginUsr;
jquery_1.default.get("usercontext", (res) => {
    if (res.status == "error")
        window.location.href = "/login";
    else {
        loginUsr = res.obj;
        jquery_1.default.get(`/grt-cart/${loginUsr.uid}`, (res) => {
        });
    }
});

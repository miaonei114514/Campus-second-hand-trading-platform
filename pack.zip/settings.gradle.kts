rootProject.name = "SchoolShop"
